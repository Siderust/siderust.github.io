
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was siderust_cppConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################

include(CMakeFindDependencyMacro)

find_dependency(qtty_cpp 0.4.5 REQUIRED)
find_dependency(tempoch_cpp 0.5.4 REQUIRED)

# ---------------------------------------------------------------------------
# Reconstruct the absolute install paths from PACKAGE_PREFIX_DIR (set by
# 
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was siderust_cppConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################) and the install-tree CMAKE_INSTALL_* directories that were
# baked in at configure time via PATH_VARS.
# ---------------------------------------------------------------------------
set_and_check(SIDERUST_CPP_INCLUDE_DIR "${PACKAGE_PREFIX_DIR}/include")
set_and_check(SIDERUST_CPP_LIB_DIR     "${PACKAGE_PREFIX_DIR}/lib")

# Runtime shared library (DLL on Windows, .so/.dylib elsewhere).
if(WIN32)
    set_and_check(SIDERUST_CPP_BINDIR "${PACKAGE_PREFIX_DIR}/bin")
    set(SIDERUST_FFI_LIBRARY "${SIDERUST_CPP_BINDIR}/libsiderust_ffi.so")
    set(SIDERUST_FFI_IMPLIB "${SIDERUST_CPP_LIB_DIR}/")
else()
    set(SIDERUST_FFI_LIBRARY "${SIDERUST_CPP_LIB_DIR}/libsiderust_ffi.so")
endif()

if(NOT EXISTS "${SIDERUST_FFI_LIBRARY}")
    set(siderust_cpp_FOUND FALSE)
    set(siderust_cpp_NOT_FOUND_MESSAGE
        "siderust_cpp: bundled siderust_ffi shared library not found at ${SIDERUST_FFI_LIBRARY}")
    return()
endif()

if(WIN32 AND NOT EXISTS "${SIDERUST_FFI_IMPLIB}")
    set(siderust_cpp_FOUND FALSE)
    set(siderust_cpp_NOT_FOUND_MESSAGE
        "siderust_cpp: bundled siderust_ffi import library not found at ${SIDERUST_FFI_IMPLIB}")
    return()
endif()

# ---------------------------------------------------------------------------
# Workaround for official qtty-cpp / tempoch-cpp packages: their installed
# *Targets.cmake exports the bare names `qtty_ffi` and `tempoch_ffi` in
# INTERFACE_LINK_LIBRARIES, but neither *Config.cmake defines a matching
# imported target in the installed tree. Worse, those configs currently bake in a broken
# absolute path for QTTY_FFI_LIBRARY / TEMPOCH_FFI_LIBRARY (the @PACKAGE_*@
# substitution did not include CMAKE_INSTALL_PREFIX in PATH_VARS, so the
# path comes out as e.g. "/lib/libqtty_ffi.so").
#
# Instead of trusting QTTY_FFI_LIBRARY / TEMPOCH_FFI_LIBRARY, locate the shared
# libraries ourselves under the dependency package prefixes and this package's prefix.
# ---------------------------------------------------------------------------
set(_siderust_config_libdir "lib")
set(_siderust_config_bindir "bin")
set(_siderust_ffi_search_paths
    "${PACKAGE_PREFIX_DIR}/${_siderust_config_libdir}"
    "${PACKAGE_PREFIX_DIR}/${_siderust_config_bindir}"
    "${PACKAGE_PREFIX_DIR}/lib"
    "${PACKAGE_PREFIX_DIR}/lib64"
    "${PACKAGE_PREFIX_DIR}/bin"
    "${SIDERUST_CPP_LIB_DIR}")
if(WIN32)
    list(APPEND _siderust_ffi_search_paths "${SIDERUST_CPP_BINDIR}")
endif()
foreach(_siderust_dependency_config_dir IN ITEMS "${qtty_cpp_DIR}" "${tempoch_cpp_DIR}")
    if(_siderust_dependency_config_dir)
        get_filename_component(_siderust_dependency_prefix
            "${_siderust_dependency_config_dir}/../../.." ABSOLUTE)
        list(APPEND _siderust_ffi_search_paths
            "${_siderust_dependency_prefix}/${_siderust_config_libdir}"
            "${_siderust_dependency_prefix}/${_siderust_config_bindir}"
            "${_siderust_dependency_prefix}/lib"
            "${_siderust_dependency_prefix}/lib64"
            "${_siderust_dependency_prefix}/bin")
    endif()
endforeach()

if(NOT TARGET qtty_ffi)
    if(WIN32)
        find_library(_siderust_qtty_ffi_path
            NAMES qtty_ffi
            PATHS ${_siderust_ffi_search_paths}
            NO_DEFAULT_PATH)
    else()
        find_library(_siderust_qtty_ffi_path
            NAMES qtty_ffi libqtty_ffi
            PATHS ${_siderust_ffi_search_paths}
            NO_DEFAULT_PATH)
    endif()
    if(NOT _siderust_qtty_ffi_path)
        set(siderust_cpp_FOUND FALSE)
        set(siderust_cpp_NOT_FOUND_MESSAGE
            "siderust_cpp: could not locate qtty_ffi under ${_siderust_ffi_search_paths}")
        return()
    endif()
    add_library(qtty_ffi SHARED IMPORTED)
    set_target_properties(qtty_ffi PROPERTIES IMPORTED_LOCATION "${_siderust_qtty_ffi_path}")
endif()

if(NOT TARGET tempoch_ffi)
    if(WIN32)
        find_library(_siderust_tempoch_ffi_path
            NAMES tempoch_ffi
            PATHS ${_siderust_ffi_search_paths}
            NO_DEFAULT_PATH)
    else()
        find_library(_siderust_tempoch_ffi_path
            NAMES tempoch_ffi libtempoch_ffi
            PATHS ${_siderust_ffi_search_paths}
            NO_DEFAULT_PATH)
    endif()
    if(NOT _siderust_tempoch_ffi_path)
        set(siderust_cpp_FOUND FALSE)
        set(siderust_cpp_NOT_FOUND_MESSAGE
            "siderust_cpp: could not locate tempoch_ffi under ${_siderust_ffi_search_paths}")
        return()
    endif()
    add_library(tempoch_ffi SHARED IMPORTED)
    set_target_properties(tempoch_ffi PROPERTIES IMPORTED_LOCATION "${_siderust_tempoch_ffi_path}")
endif()

# Imported target for the bundled siderust FFI shared library so consumers
# that link against siderust::siderust_cpp resolve siderust_ffi symbols
# transitively.
if(NOT TARGET siderust::siderust_ffi)
    add_library(siderust::siderust_ffi SHARED IMPORTED)
    set(_siderust_ffi_props
        IMPORTED_LOCATION "${SIDERUST_FFI_LIBRARY}"
        INTERFACE_INCLUDE_DIRECTORIES "${SIDERUST_CPP_INCLUDE_DIR}"
    )
    if(WIN32)
        list(APPEND _siderust_ffi_props IMPORTED_IMPLIB "${SIDERUST_FFI_IMPLIB}")
    endif()
    set_target_properties(siderust::siderust_ffi PROPERTIES ${_siderust_ffi_props})
endif()

include("${CMAKE_CURRENT_LIST_DIR}/siderust_cppTargets.cmake")

# Legacy variables for non-target-based consumers.
set(SIDERUST_CPP_LIBRARIES    siderust::siderust_cpp)
set(SIDERUST_CPP_INCLUDE_DIRS "${SIDERUST_CPP_INCLUDE_DIR}")

check_required_components(siderust_cpp)
